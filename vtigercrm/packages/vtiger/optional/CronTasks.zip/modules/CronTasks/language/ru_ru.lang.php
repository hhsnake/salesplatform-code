<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
        'LBL_ACTIVE' => 'Активный',
        'LBL_INACTIVE' => 'Неактивный',
        'LBL_STATUS' => 'Статус',
        'LBL_SCHEDULER' => 'Планировщик',
        'LBL_SETTINGS' => 'Настройки',
        'LBL_FREQUENCY'=> 'Частота',
        'LBL_HOURMIN' => '(Ч:М)',
        'LAST_START'=>'Последнее сканирование начато',
        'LAST_END'=>'Последнее сканирование окончено',
        'LBL_SEQUENCE'=>'Последовательность',
        'LBL_TOOLS' =>'Инструменты',
        'LBL_DAYS'=>'Дней',
        'LBL_HOURS'=>'Часов',
        'LBL_MINS'=>'Минут',
        'LBL_RUNNING'=>'Запущено',
        'LBL_MINIMUM_FREQUENCY'=>'Частота либого cron-задания должна быть больше 15 минут',
		'LBL_SECONDS'=>'сек назад',
		'LBL_MINUTES'=>'мин назад',
		'LBL_HOURS'=>'час назад',
		'LBL_DAYS'=>'дней назад',
		'LBL_MONTHS'=>'месяев назад',
		'LBL_YEARS'=>'дней назад',
);
?>
