<?php
/** YOUR LICENSE TEXT HERE **/
require_once('include/Ajax/CommonAjax.php');
?>
