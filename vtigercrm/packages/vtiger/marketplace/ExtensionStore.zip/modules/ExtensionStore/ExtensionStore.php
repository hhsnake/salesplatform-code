<?php
/* 
* Copyright (C) www.vtiger.com. All rights reserved.
* @license Proprietary
*/
Class ExtensionStore{

}
?>
