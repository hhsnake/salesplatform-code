<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
	'SINGLE_Documents'             => 'Document'                    , 
	'Documents'                    => 'Documents'                   , // TODO: Review
	'LBL_ADD_RECORD'               => 'Add Document'                , 
	'LBL_RECORDS_LIST'             => 'Documents List'              , 
	'LBL_NOTE_INFORMATION'         => 'Information document'        , 
	'LBL_FILE_INFORMATION'         => 'Information fichier'         , 
	'LBL_DESCRIPTION'              => 'Description'                 , 
	'Title'                        => 'Titre'                       , 
	'File Name'                    => 'Nom du fichier'              , 
	'Note'                         => 'Notes'                       , 
	'File Type'                    => 'Type du fichier'             , 
	'File Size'                    => 'Taille'                      , 
	'Download Type'                => 'Type de téléchargement'    , 
	'Version'                      => 'Version'                     , 
	'Active'                       => 'Actif'                       , 
	'Download Count'               => 'Compteur de téléchargement', 
	'Folder Name'                  => 'Répertoire'                 , 
	'Document No'                  => 'Document N°'                , 
	'Last Modified By'             => 'Last Modified By'            , 
	'LBL_FOLDER_HAS_DOCUMENTS'     => 'Please move documents from folder before deleting', 
	'LBL_DOWNLOAD_FILE'            => 'Télécharger le fichier'    , 
	'LBL_CHECK_FILE_INTEGRITY'     => 'Contrôler l\'intégrité du fichier', 
	'LBL_INTERNAL'                 => 'Interne'                     , 
	'LBL_EXTERNAL'                 => 'Externe'                     , 
	'LBL_MAX_UPLOAD_SIZE'          => 'Maximum upload size'         , 
	'LBL_MOVE'                     => 'Déplacer'                   , 
	'LBL_ADD_FOLDER'               => 'Ajouter un dossier'          , 
	'LBL_FOLDERS_LIST'             => 'Folders List'                , 
	'LBL_FOLDERS'                  => 'Folders'                     , 
	'LBL_DOCUMENTS_MOVED_SUCCESSFULLY' => 'Documents Moved Successfully', 
	'LBL_DENIED_DOCUMENTS'         => 'Denied Documents'            , 
	'MB'                           => 'Mo'                          , 
	'LBL_ADD_NEW_FOLDER'           => 'Ajouter un dossier'          , 
	'LBL_FOLDER_NAME'              => 'Répertoire'                 , 
	'LBL_FOLDER_DESCRIPTION'       => 'Folder Description'          , 
	'LBL_FILE_AVAILABLE'           => 'File is available for download', 
	'LBL_FILE_NOT_AVAILABLE'       => 'This Document is not available for Download', 
);
$jsLanguageStrings = array(
	'JS_NEW_FOLDER'                => 'New Folder'                  , 
	'JS_MOVE_DOCUMENTS'            => 'Move Documents'              , 
	'JS_ARE_YOU_SURE_YOU_WANT_TO_MOVE_DOCUMENTS_TO' => 'Are you sure you want to move the file(s) to', 
	'JS_FOLDER'                    => 'folder'                      , 
	'JS_OPERATION_DENIED'          => 'Operation Denied'            , 
);