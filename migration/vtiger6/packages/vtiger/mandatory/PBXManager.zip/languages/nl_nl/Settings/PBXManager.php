<?php

/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * *********************************************************************************** */
$languageStrings = array(
    'LBL_SELECT_ONE' => 'Selecteer',
    'LBL_PBXMANAGER' =>'PBXManager',
    'LBL_PBXMANAGER_CONFIG' => 'Asterisk-Server-gegevens',
    'LBL_NOTE' => 'Note:',
    'LBL_INFO_WEBAPP_URL' => 'Configureer uw Asterisk App-URL in het formaat', 
    'LBL_FORMAT_WEBAPP_URL' => '(Protocol) :/ / (asterisk_ip): (poort)',
    'LBL_FORMAT_INFO_WEBAPP_URL' => 'ex: http://0.0.0.0:5000',
    'LBL_INFO_CONTEXT' => 'Vtiger Specfic context geconfigureerd in uw Asterisk server (extensions.conf)',
    'LBL_PBXMANAGER_INFO' => 'Configure Asterisk-Server-gegevens na Installeren Vtiger Asterisk Connector  in uw Asterisk-Server',
    
    'webappurl'=>'Vtiger Askterisk Web URL',
    'vtigersecretkey'=>'Vtiger Secret Key',
    'outboundcontext' => 'Outbound Context',
    'outboundtrunk' => 'Outbound Trunk',
    
);

$jsLanguageStrings = array(
    
);
?>  
